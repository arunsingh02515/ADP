package com.byteslounge.cdi.bean;

public class ServiceBean implements Service {
	
	@Override
	public int doWork(int a, int b) {
		System.out.println("daf");
		return a + b;
	}

}
