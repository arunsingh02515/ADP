package Adp.vehicalIdentification;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;



import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.adp.configuration.AppConfig;
import com.adp.controller.VehicalIdentificationController;
import com.adp.model.Vehical;
import com.adp.model.VehicalTypeEnum;
import com.adp.model.Vehicals;


/**
 * Unit test for simple App.
 */
public class AppTest 
   
{
	
	 
	@Test
   public void testVehicalType(){
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		VehicalIdentificationController vehicalIdentificationController = (VehicalIdentificationController) context.getBean("vehicalIdentificationController");
	   Vehicals vehicals=vehicalIdentificationController.loadXmlData();
	   List<Vehical> vechicalList=vehicals.getVehicle();
	   	   
	   Map<String,VehicalTypeEnum> mapVehicalType=vehicalIdentificationController.findVehicalType(vechicalList);
	   System.out.println("************Priting vehicals Id with Vehicals Type****************");
	   System.out.println(mapVehicalType);
	   System.out.println("************Priting how many vehicals of each Type****************");
	   List<VehicalTypeEnum> listOfVehical=new ArrayList<VehicalTypeEnum>( mapVehicalType.values());
	   Map<String,Integer> noOfTimes=  vehicalIdentificationController.calculateNumberOfVehicalEachType(listOfVehical) ;                    
	   System.out.println(noOfTimes);
   }

	
}
