package com.adp.service.impl;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.adp.model.FrameEnum;
import com.adp.model.PowertrainEnum;
import com.adp.model.Vehical;
import com.adp.model.VehicalTypeEnum;
import com.adp.model.WheelMaterialEnum;
import com.adp.model.Wheels;
import com.adp.service.VehicalIdentificationService;



@Service
public class VehicalIdentificationServiceImpl implements VehicalIdentificationService{

public	Map<String, VehicalTypeEnum> findVehicalType(List<Vehical> vechicalList){
		Map<String,VehicalTypeEnum> mapVehicalType=new LinkedHashMap<String,VehicalTypeEnum>();
		String vehicalId=null;
		int noOfWheel=0;
		String wheelMaterial=null;
		for(Vehical vehicalType:vechicalList){
			vehicalId=vehicalType.getId();
			String material=vehicalType.getFrame().getMaterial();
			Wheels wheels=vehicalType.getWheels();
			String powertrain=vehicalType.getPowertrain().getHuman();
			if(null!=wheels){
			 noOfWheel=wheels.getWheel().size();
			 wheelMaterial= wheels.getWheel().get(0).getMaterial();
			}
			if(material.equals(String.valueOf(FrameEnum.plastic))&& powertrain.equals(String.valueOf(PowertrainEnum.human))&& (null!=wheels &&noOfWheel ==3 && wheelMaterial.equals(String.valueOf(WheelMaterialEnum.plastic))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.BigWheel);
					
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.human))&& (null!=wheels &&noOfWheel ==2 && wheelMaterial.equals(String.valueOf(WheelMaterialEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Bicycle);
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.InternalCombustion))&& (null!=wheels &&noOfWheel ==2 && wheelMaterial.equals(String.valueOf(WheelMaterialEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Motorcycle);
						
			if(material.equals(String.valueOf(FrameEnum.plastic))&& powertrain.equals(String.valueOf(PowertrainEnum.Bernoulli))&& null==wheels )
				mapVehicalType.put(vehicalId, VehicalTypeEnum.HangGlider);
			if(material.equals(String.valueOf(FrameEnum.metal))&& powertrain.equals(String.valueOf(PowertrainEnum.InternalCombustion))&& (null!=wheels &&noOfWheel ==4 && wheelMaterial.equals(String.valueOf(WheelMaterialEnum.metal))))
				mapVehicalType.put(vehicalId, VehicalTypeEnum.Car);
								
		}
		return mapVehicalType;
	}
	public  Map<String, Integer> calculateNumberOfVehicalEachType(
				List<VehicalTypeEnum> listOfVehical){
		  Map<String, Integer> map=new LinkedHashMap<String,Integer>();
			for(VehicalTypeEnum vehical:listOfVehical){
				  Integer i=map.get(String.valueOf(vehical));
				  if(i==null)
					  map.put(String.valueOf(vehical), 1);
				  else
					  map.put(String.valueOf(vehical), i+1);
				
			}
			return map;
		  
	  }
}
