package com.adp.service;

import java.util.List;
import java.util.Map;

import com.adp.model.Vehical;
import com.adp.model.VehicalTypeEnum;



public interface VehicalIdentificationService {
	 Map<String, VehicalTypeEnum> findVehicalType(List<Vehical> vechicalList);
	  Map<String, Integer> calculateNumberOfVehicalEachType(
				List<VehicalTypeEnum> listOfVehical);
}
