package com.adp.model;

public enum WheelMaterialEnum {
	plastic, metal
	
			
}
