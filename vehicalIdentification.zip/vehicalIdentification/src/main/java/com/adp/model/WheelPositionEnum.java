package com.adp.model;

public enum WheelPositionEnum {
  left,right,top,rear
}
