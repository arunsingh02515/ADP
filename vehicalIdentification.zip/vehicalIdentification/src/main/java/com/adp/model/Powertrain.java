package com.adp.model;

public class Powertrain {
private String human;

public String getHuman() {
	return human;
}

public void setHuman(String human) {
	this.human = human;
}

}
