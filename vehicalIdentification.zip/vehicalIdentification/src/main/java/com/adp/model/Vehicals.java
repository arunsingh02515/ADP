package com.adp.model;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name="vehicles")
public class Vehicals {
	
	List<Vehical> vehicle;
	@XmlElement(required=true)
	public List<Vehical> getVehicle() {
		return vehicle;
	}

	public void setVehicle(List<Vehical> vehicle) {
		this.vehicle = vehicle;
	}
	
}
