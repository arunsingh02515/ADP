package com.adp.model;

public enum PowertrainEnum {
	human,InternalCombustion,Bernoulli
}
