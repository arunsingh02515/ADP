package com.adp.controller;

import java.util.List;
import java.util.Map;

import javax.naming.spi.ObjectFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.adp.model.Vehical;
import com.adp.model.VehicalTypeEnum;
import com.adp.model.Vehicals;
import com.adp.service.VehicalIdentificationService;


/**
 * Hello world!
 *
 */
@Component("vehicalIdentificationController")
public class VehicalIdentificationController
{
	@Autowired
	VehicalIdentificationService vehicalIdentificationService;
	
	//Load xml data from classpath... 
    public Vehicals  loadXmlData(){
    	Vehicals vehicals =null;
    	try {
	JAXBContext jaxbContext = JAXBContext.newInstance(Vehicals.class);

	Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
	 vehicals = (Vehicals) jaxbUnmarshaller.unmarshal(ClassLoader.getSystemResourceAsStream("vehicles.xml"));
	
    	}
    	catch(Exception e){
    		e.printStackTrace();
    	}
    	 return vehicals;	
       
    }
    
   public Map<String, VehicalTypeEnum> findVehicalType(List<Vehical> vechicalList){
    	return vehicalIdentificationService.findVehicalType(vechicalList);
    }
	public  Map<String, Integer> calculateNumberOfVehicalEachType(
				List<VehicalTypeEnum> listOfVehical){
		  return vehicalIdentificationService.calculateNumberOfVehicalEachType(listOfVehical);
	  }
    
   
}
