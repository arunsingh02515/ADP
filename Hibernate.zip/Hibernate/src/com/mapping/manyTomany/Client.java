package com.mapping.manyTomany;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.*;  
import org.hibernate.cfg.*;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    Set<Course> courses = new HashSet<Course>();
		courses.add(new Course("Maths"));
		courses.add(new Course("Computer Science"));

		Student student1 = new Student("Eswar", courses);
		Student student2 = new Student("Joe", courses);
		session.save(student1);
		session.save(student2);
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
