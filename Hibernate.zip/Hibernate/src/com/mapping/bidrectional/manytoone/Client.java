package com.mapping.bidrectional.manytoone;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;  
import org.hibernate.cfg.*;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    Address address = new Address("OMR Road1", "Chennai", "TN", "600097");
		Student student1 = new Student("Eswar1", address);
		Student student2 = new Student("Joe1", address);
		List<Student> studentList=new ArrayList<Student>();
		studentList.add(student1);
		studentList.add(student2);
		student1.setAddress(address);
		student2.setAddress(address);
		address.setStudent(studentList);
		/*student1.setStudentAddress(addressList);
		student2.setStudentAddress(addressList);
		address.setStudent(student1);
		address.setStudent(student2);*/
		session.save(address);
		List<Student> students = (List<Student>) session.createQuery(
		"from Student ").list();
for (Student s : students) {
	System.out.println("Student Details : " + s);
	System.out.println("Student Address Details: "
			+ s.getAddress());
}
		//session.save(student2);
	   // session.save(p);
	    
	    
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
