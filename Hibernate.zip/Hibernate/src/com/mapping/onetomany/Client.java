package com.mapping.onetomany;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.*;  
import org.hibernate.cfg.*;

import com.mapping.bidrection.Phone;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    AccountEntity account1 = new AccountEntity();
        account1.setAccountNumber("Account detail 71a");
 
        AccountEntity account2 = new AccountEntity();
        account2.setAccountNumber("Account detail 75sa");
 
        AccountEntity account3 = new AccountEntity();
        account3.setAccountNumber("Account detail 31aa");
 
        //Add new Employee object
        EmployeeEntity firstEmployee = new EmployeeEntity();
        firstEmployee.setEmail("arunksingh2a@mail.com");
        firstEmployee.setFirstName("arun811a");
        firstEmployee.setLastName("kumar11a");
 
        EmployeeEntity secondEmployee = new EmployeeEntity();
        secondEmployee.setEmail("demo-user-seconda2@mail.com");
        secondEmployee.setFirstName("demo-two12a");
        secondEmployee.setLastName("user-two12a");
 
        Set<AccountEntity> accountsOfFirstEmployee = new HashSet<AccountEntity>();
        accountsOfFirstEmployee.add(account1);
        accountsOfFirstEmployee.add(account2);
 
        Set<AccountEntity> accountsOfSecondEmployee = new HashSet<AccountEntity>();
        accountsOfSecondEmployee.add(account3);
 
        firstEmployee.setAccounts(accountsOfFirstEmployee);
        secondEmployee.setAccounts(accountsOfSecondEmployee);
        //Save Employee
        session.save(firstEmployee);
        
       session.save(secondEmployee);
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
