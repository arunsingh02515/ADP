package com.mapping;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="phone111" ,schema="system")
public class Phone {
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen") 
	private int id;
	private String comment;
	private String number;
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="sid",nullable=false)
	private Student student;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	//other fields and getter/setter methods
}
