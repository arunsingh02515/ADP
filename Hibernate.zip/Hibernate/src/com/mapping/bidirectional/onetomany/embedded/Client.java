package com.mapping.bidirectional.onetomany.embedded;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.*;  
import org.hibernate.cfg.*;

import com.mapping.onetomany.AccountEntity;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	   AccountEntity1 account1 = new AccountEntity1();
        account1.setAccountNumber("Account detail 3");
 
        AccountEntity1 account2 = new AccountEntity1();
        account2.setAccountNumber("Account detail 4");
 
       
 
        //Add new Employee object
        EmployeeEntity1 firstEmployee = new EmployeeEntity1();
        firstEmployee.setEmail("kkkksingh@mail.com");
        firstEmployee.setFirstName("arun");
        firstEmployee.setLastName("kumar");
        Embed e=  new Embed();
        e.setAccId(3);
        e.setEmployeeId(4);
        firstEmployee.setEmbed(e);
        Set<AccountEntity1> accountsOfFirstEmployee = new HashSet<AccountEntity1>();
        accountsOfFirstEmployee.add(account1);
        accountsOfFirstEmployee.add(account2);
 
        account1.setEmployee(firstEmployee);
        account2.setEmployee(firstEmployee);
        
        firstEmployee.setAccounts(accountsOfFirstEmployee);
 
        session.save(firstEmployee);
        t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
