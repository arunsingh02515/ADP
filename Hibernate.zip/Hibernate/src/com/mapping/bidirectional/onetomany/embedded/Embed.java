package com.mapping.bidirectional.onetomany.embedded;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Embed implements Serializable{
	 @Column(name = "emp_id")
	private Integer employeeId;
	 @Column(name = "acc_id")
	private Integer accId;

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Integer getAccId() {
		return accId;
	}

	public void setAccId(Integer accId) {
		this.accId = accId;
	}

	
	
	
}
