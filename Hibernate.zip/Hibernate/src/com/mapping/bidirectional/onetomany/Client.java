package com.mapping.bidirectional.onetomany;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.*;  
import org.hibernate.cfg.*;

import com.mapping.onetomany.AccountEntity;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    com.mapping.bidirectional.onetomany.AccountEntity account1 = new com.mapping.bidirectional.onetomany.AccountEntity();
        account1.setAccountNumber("Account detail 3");
 
        com.mapping.bidirectional.onetomany.AccountEntity account2 = new com.mapping.bidirectional.onetomany.AccountEntity();
        account2.setAccountNumber("Account detail 4");
 
       
 
        //Add new Employee object
        EmployeeEntity firstEmployee = new EmployeeEntity();
        firstEmployee.setEmail("kkkksingh@mail.com");
        firstEmployee.setFirstName("arun");
        firstEmployee.setLastName("kumar");
 
       
 
        Set<com.mapping.bidirectional.onetomany.AccountEntity> accountsOfFirstEmployee = new HashSet<com.mapping.bidirectional.onetomany.AccountEntity>();
        accountsOfFirstEmployee.add(account1);
        accountsOfFirstEmployee.add(account2);
 
       
        firstEmployee.setAccounts(accountsOfFirstEmployee);
        
        account1.setEmployee(firstEmployee);
        account2.setEmployee(firstEmployee);
        session.save(firstEmployee);
       // session.save(secondEmployee);
        List<com.mapping.bidirectional.onetomany.AccountEntity> accountEntity = (List<com.mapping.bidirectional.onetomany.AccountEntity>)session.createQuery("from AccountEntity ").list();
		for(com.mapping.bidirectional.onetomany.AccountEntity p1: accountEntity){
			System.out.println("Details : "+p1.getEmployee().getEmail());
		}
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
