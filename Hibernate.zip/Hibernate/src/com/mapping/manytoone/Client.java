package com.mapping.manytoone;


import org.hibernate.*;  
import org.hibernate.cfg.*;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    Address address = new Address("OMR Road1", "Chennai", "TN", "600097");
		//By using cascade=all option the address need not be saved explicitly when the student object is persisted the address will be automatically saved.
        //session.save(address);
		Student student1 = new Student("Eswar1", address);
		Student student2 = new Student("Joe1", address);
		student1.setStudentAddress(address);
		student2.setStudentAddress(address);
		session.save(student1);
		session.save(student2);
	   // session.save(p);
	    
	    
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
