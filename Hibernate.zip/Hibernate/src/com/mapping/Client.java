package com.mapping;


import org.hibernate.*;  
import org.hibernate.cfg.*;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    Student s= new Student();
	    s.setName("arun");
	    Phone p=new Phone();
	    p.setComment("mm");
	    p.setNumber("111");
	    s.setPhone(p);
	    session.save(p);
	    session.save(s);
	    
	    
	    
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
