package com.mapping;

import javax.persistence.Entity;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
	@Entity
	@Table(name="student111", schema="system")
	public class Student {

		@Id
		@GenericGenerator(name="kaugen" , strategy="increment")
		 @GeneratedValue(generator="kaugen") 
		private int sid;
		
		private String name;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy="student")
		
		private Phone phone;
		
		//other fields and getter/setter methods
		public int getSid() {
			return sid;
		}
		public void setSid(int sid) {
			this.sid = sid;
		}
		public Phone getPhone() {
			return phone;
		}
		public void setPhone(Phone phone) {
			this.phone = phone;
		}
	}

