package com.mapping.bidrection;


import java.util.List;

import org.hibernate.*;  
import org.hibernate.cfg.*;
public class Client {
 public static void main(String args[]){
	 AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure().buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction(); 
	    Student s= new Student();
	    s.setName1("arunksingh");
	    Phone p=new Phone();
	    p.setComment1("mmkk");
	    p.setNumber1("1112");
	    s.setPhone1(p);
	    p.setStudent(s);
	    session.save(s);
	   // session.save(p);
	    List<Student> students = (List<Student>)session.createQuery("from Student ").list();
		for(Student s1: students){
			System.out.println("Details : "+s1.getPhone1().getNumber1());
		}
		List<Phone> phone = (List<Phone>)session.createQuery("from Phone ").list();
		for(Phone p1: phone){
			System.out.println("Details : "+p1.getStudent().getName1());
		}
	    t.commit();
	    System.out.print("success");
	    session.close();
	    
	      
	 
 }
}
