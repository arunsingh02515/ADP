package com.mapping.bidrection;

import javax.persistence.Entity;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
	@Entity
	@Table(name="student121", schema="system")
	public class Student {

		@Id
		@GenericGenerator(name="kaugen1" , strategy="increment")
		 @GeneratedValue(generator="kaugen1") 
		 //@GeneratedValue
		private int sid1;
		
		private String name1;
		public String getName1() {
			return name1;
		}
		public void setName1(String name1) {
			this.name1 = name1;
		}
		@OneToOne(mappedBy="student", cascade = CascadeType.ALL)
		//@PrimaryKeyJoinColumn
		private Phone phone1;
		
		//other fields and getter/setter methods
		public int getSid1() {
			return sid1;
		}
		public void setSid1(int sid1) {
			this.sid1 = sid1;
		}
		public Phone getPhone1() {
			return phone1;
		}
		public void setPhone1(Phone phone1) {
			this.phone1 = phone1;
		}
	}

