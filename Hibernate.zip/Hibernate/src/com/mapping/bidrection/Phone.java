package com.mapping.bidrection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="phone121" ,schema="system")

public class Phone {
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen") 
	//@GeneratedValue
	private int pid1;
	
	private String comment1;
	private String number1;
	@OneToOne
	@JoinColumn(name="idval" ,referencedColumnName = "sid1")
	//@PrimaryKeyJoinColumn
	private Student student;
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
/*	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}*/
	//@OneToOne(fetch=FetchType.LAZY)
	//@JoinColumn(name="sid",nullable=false)
	//private Student student;
	
	public int getPid1() {
		return pid1;
	}
	public void setPid1(int pid1) {
		this.pid1 = pid1;
	}
	public String getComment1() {
		return comment1;
	}
	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}
	public String getNumber1() {
		return number1;
	}
	public void setNumber1(String number1) {
		this.number1 = number1;
	}
	
	//other fields and getter/setter methods
}
