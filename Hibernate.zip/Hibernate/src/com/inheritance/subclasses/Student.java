package com.inheritance.subclasses;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="Student" ,schema="system")
@PrimaryKeyJoinColumn(name="personid") 
public class Student extends Person {
	
 private String courseName;
 public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
private String grade;
 
 
}
