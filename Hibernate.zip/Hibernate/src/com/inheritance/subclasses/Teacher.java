package com.inheritance.subclasses;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="Teacher" ,schema="system")
@PrimaryKeyJoinColumn(name="personid") 
public class Teacher extends Person{
  private int salary;

public int getSalary() {
	return salary;
}

public void setSalary(int i) {
	this.salary = i;
}
}
