package com.inheritance.subclasses;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity  
@Table(name = "person")  
@Inheritance(strategy=InheritanceType.JOINED)  

public abstract class Person {
  
	@Id  
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen") 
	private int personid;
  public Present_Address getPresent_Address() {
		return present_Address;
	}
	public void setPresent_Address(Present_Address present_Address) {
		this.present_Address = present_Address;
	}
	public Permanent_Address getPermanent_Address() {
		return permanent_Address;
	}
	public void setPermanent_Address(Permanent_Address permanent_Address) {
		this.permanent_Address = permanent_Address;
	}
public int getPersonid() {
		return personid;
	}
	public void setPersonid(int personid) {
		this.personid = personid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
  private String name;
  private String email;
  @OneToOne(mappedBy="person", cascade = CascadeType.ALL)
	private Present_Address present_Address; 
  @OneToOne(mappedBy="person1", cascade = CascadeType.ALL)
	private Permanent_Address permanent_Address; 
  
  
}
