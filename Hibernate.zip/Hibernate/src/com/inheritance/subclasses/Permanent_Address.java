package com.inheritance.subclasses;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Permanent_Address" ,schema="system")
public class Permanent_Address {
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen") 	
 private int addressId;
 
 public int getAddressId() {
	return addressId;
}
public void setAddressId(int addressId) {
	this.addressId = addressId;
}
public Person getPerson1() {
	return person1;
}
public void setPerson(Person person1) {
	this.person1 = person1;
}
public String getVillage() {
	return village;
}
public void setVillage(String village) {
	this.village = village;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
private String village;
 private String district;
 @OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="personid")
	private Person person1;
 
}
