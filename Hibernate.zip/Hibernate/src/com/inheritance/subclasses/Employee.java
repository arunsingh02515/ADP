package com.inheritance.subclasses;


	import javax.persistence.*;  

import org.hibernate.annotations.GenericGenerator;
	  
	@Entity  
	@Table(name = "employee103")  
	@Inheritance(strategy=InheritanceType.JOINED)  
	  
	public class Employee {  
	

	@Id  
	@GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen") 
	      
	@Column(name = "id")  
	private int id;  
	  
	@Column(name = "name")  
	private String name; 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
