package com.inheritance.subclasses;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main1 {
	public static void main(String args[])
	{  
		 
		 AnnotationConfiguration cfg=new AnnotationConfiguration();  
		 SessionFactory sf =cfg.configure().buildSessionFactory();
		Session s1=  sf.openSession(); 
		      
		Transaction t=s1.beginTransaction(); 
		    Employee1 emp= (Employee1)s1.get(Employee1.class,1);
		    s1.close(); 
		    t.commit();  
		  
		    Session s2=  sf.openSession();
		    Transaction t1=s2.beginTransaction(); 
		    Employee1 emp1= (Employee1)s2.get(Employee1.class,1);
		     s2.merge(emp);
		   // System.out.println(emp==emp2);
		   emp1.setName("aa");
		    t1.commit();
		    s2.close();
		     
		    /*Employee1 emp= new Employee1();
		    emp.setName("abc");
		    emp.setAddress("pp");
		    session.save(emp);
		    session.flush();*/
		   
		    
		    System.out.println("success"); 	      
		    
	} 
}
