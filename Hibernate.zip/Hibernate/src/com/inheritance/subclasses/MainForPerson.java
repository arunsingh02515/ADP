package com.inheritance.subclasses;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class MainForPerson {
	public static void main(String args[])
	{  
		 
		 AnnotationConfiguration cfg=new AnnotationConfiguration();  
		    Session session=cfg.configure().buildSessionFactory().openSession();  
		      
		    Transaction tx=session.beginTransaction(); 
		    Student s= new Student();
		    s.setName("Manoj1");
		    s.setEmail("aa@gmail.com");
		    s.setCourseName("B.tech");
		    s.setGrade("A");

		    Teacher t= new Teacher();
		    t.setName("MMSir1");
		    t.setEmail("mm@gmail.com");
		    t.setSalary(10000);
		    
		    Present_Address present_Address= new Present_Address();
		    present_Address.setVillage("dharm1");
		    present_Address.setDistrict("samast");
		    
		    Present_Address present_Address1= new Present_Address();
		    present_Address1.setVillage("dharmforTeacher");
		    present_Address1.setDistrict("samast1");
		    
		    Permanent_Address permanent_Address= new Permanent_Address();
		    permanent_Address.setVillage("ppp");
		    permanent_Address.setDistrict("ppdis");
		    
		    Permanent_Address permanent_Address1= new Permanent_Address();
		    permanent_Address1.setVillage("pppForSir");
		    permanent_Address1.setDistrict("ppdis");
		    s.setPresent_Address(present_Address);
		    s.setPermanent_Address(permanent_Address);
		    
		    t.setPresent_Address(present_Address1);
		    t.setPermanent_Address(permanent_Address1);
		    present_Address.setPerson(s);
		    present_Address1.setPerson(t);
		    permanent_Address.setPerson(s);
		    permanent_Address1.setPerson(t);
		    session.save(s);
		    session.save(t);
		    /*session.save(permanent_Address);
		    session.save(permanent_Address1);
		    session.save(present_Address);
		    session.save(present_Address1);*/
		    tx.commit();  
		    session.close();  
		    System.out.println("success");		    
}
}
