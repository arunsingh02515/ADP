package com.inheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {
	static SessionFactory sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();  
	static  Session session = sessionFactory.openSession(); 
	 public static void main(String args[])
	{  
		 
		 saveData();
		 
		 }  
	 public static void saveData(){
		 session.beginTransaction();  
		    
		  Vehicle vehicle = new Vehicle();  
		  //vehicle.setVehicleName("Car11");  
		    
		  TwoWheeler twoWheeler = new TwoWheeler();  
		  twoWheeler.setVehicleName("Bike1");  
		  twoWheeler.setSteeringTwoWheeler("Bike Steering Handle");  
		    
		  FourWheeler fourWheeler = new FourWheeler();  
		  fourWheeler.setVehicleName("Alto1");  
		  fourWheeler.setSteeringFourWheeler("Alto Steering Wheel");  
		    
		 // session.save(vehicle);  
		  session.save(twoWheeler);  
		  session.save(fourWheeler);  
		    
		  session.getTransaction().commit();  
		  session.close(); 
	 }
		}  

