package com.web;

import java.util.Date;

public class Customer {
 private int id;
 private String name;
 private String vehicalType;
 private Date date;
 
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getVehicalType() {
	return vehicalType;
}
public void setVehicalType(String vehicalType) {
	this.vehicalType = vehicalType;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
 
}
