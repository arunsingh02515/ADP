package com.web;

public class Available {
  private int number;
  private String available;
  public String getAvailable() {
	return available;
}
public void setAvailable(String available) {
	this.available = available;
}

public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
/*public int hashCode(){
	return available.hashCode();
}
public boolean equals(Object obj){
	Available available=(Available)obj;
	
	return  available.equals(available);
}*/

  
}
