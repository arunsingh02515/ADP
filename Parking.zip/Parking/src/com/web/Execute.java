package com.web;

public class Execute {
 public static void main(String args[]){
	 Test test = new Test();
	 CalculateBill m= test.calc("bike");
	 System.out.println(m.getCname()+"/"+m.getSlot()+"/"+m.getCharge()+"/"+m.getVehicalType());
	 CalculateBill m1= test.calc("car");
	 System.out.println(m1.getCname()+"/"+m1.getSlot()+"/"+m1.getCharge()+"/"+m1.getVehicalType());
	 
	 CalculateBill m3= test.calc("car");
	 System.out.println(m3.getCname()+"/"+m3.getSlot()+"/"+m3.getCharge()+"/"+m3.getVehicalType());
 }
}
