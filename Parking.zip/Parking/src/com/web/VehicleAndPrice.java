package com.web;

public enum VehicleAndPrice {
 car(20),bike(10);
  int price;
 VehicleAndPrice(int price){
	 this.price=price;
 }
}
