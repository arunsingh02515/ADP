package com.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;



public class Test {
static Map<Integer,Available> slot= null;
	static {
	slot= new LinkedHashMap<Integer,Available>(10);
	for(int i=1;i<=10;i++){
		Available available= new Available();
		available.setNumber(i);
		available.setAvailable("Yes");
		slot.put(available.getNumber(),available);
	}
 }
	public  CalculateBill calc(String bike){
		CalculateBill calculateBill =new CalculateBill();
		
		String date="17/09/2016";
		SimpleDateFormat s= new SimpleDateFormat("dd/mm/yyyy");
		Date d=null;
		try {
			d = s.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Customer cust=new Customer();
		cust.setId(1);
		cust.setName("arun");
		cust.setDate(d);
		cust.setVehicalType(bike);
		
		Available available=findParkingSlot();
		if(null!=available){
		available.setAvailable("no");
		//slot.put(available.getNumber(),available);	
		System.out.println(slot);
		
		
		   int charge= finalBill(cust);
		   calculateBill.setBillId(1);
		   calculateBill.setCid(cust.getId());
		   calculateBill.setCharge(charge);
		   calculateBill.setCname(cust.getName());
		   calculateBill.setSlot(available.getNumber());
		   calculateBill.setVehicalType(cust.getVehicalType());
		   
		}
		else {
			System.out.println("slot already booked");
		}
		return calculateBill;
		
	}
	private static int finalBill(Customer cust) {
		// TODO Auto-generated method stub
		String vehicleType=cust.getVehicalType();
		     return   getCharge(vehicleType);  
		     
		
	}
	private static int getCharge(String vehicleType) {
		// TODO Auto-generated method stub
		int price=0;
for(VehicleAndPrice e:VehicleAndPrice.values()){
			
		if(e.equals(vehicleType)){
			price=e.price;
			break;
			
		}
		
	}
return price;
	}
	//}
	private static Available findParkingSlot() {
		Available avail=null;
		for(int i=1;i<=10;i++){
			 avail=	slot.get(i);
			if(avail.getAvailable().equals("Yes")){
				//return avail;
				break;
			}
			
	
	  
	 
		// TODO Auto-generated method stub
		
		
	}
		return avail;
}
}
