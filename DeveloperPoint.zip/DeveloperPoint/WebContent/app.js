var app = angular.module('angularjs-starter', []);

app.controller('MainCtrl', ['$document','$scope', function($document, $scope) {
  // nothing to do here
  $document.bind('click', function(event){
        // alert("body click");
       
      });
}]);

app.directive('multiselect',['$document', function($document){

return {
  restrict: 'E',
  require: '?ngModel',
  scope: {
    choices: '=',
    selected: '='
  },
  templateUrl: 'select.html',
  replace: true,
  link: function(scope, element, attr){
    
      scope.isPopupVisible = false;

      scope.toggleSelect = function(){
        scope.isPopupVisible = true;
      }

      $document.bind('click', function(event){
       // scope.isPopupVisible = false;
        var isClickedElementChildOfPopup = element
          .find(event.target)
          .length > 0;
          
        if (isClickedElementChildOfPopup)
         scope.isPopupVisible = true;
        
         else
         scope.isPopupVisible = false;
        scope.$apply();
      });
  }
};
}]);