function angularController($scope) {
	//$rootScope.showAbout=true;
	$scope.abc="hello";
	$scope.subscribers=[{
		
		"id": "1",
		"name":"arun"
		
	},
	{
		"id":"2",
		"name":"kumar"
	}
	
	]
}