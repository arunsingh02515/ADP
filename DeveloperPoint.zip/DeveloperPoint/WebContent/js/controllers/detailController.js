function detailController($scope, $state, $stateParams) {
	
	$scope.foo = $stateParams.id;
}