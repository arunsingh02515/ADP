function mainController($scope, $rootScope) {
	
	//$rootScope.showPage=false;
}