package com.byteslounge.cdi.bean;

public interface Service {

	int doWork(int a, int b);
	
}
